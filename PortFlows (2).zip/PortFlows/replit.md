# Harbor & Port Operations Management System

## Overview

This is a comprehensive Role-Based Access Control (RBAC) system designed for maritime port operations. The system features premium subscription management, task automation, integration capabilities with warehouse management systems, and a hierarchical user permission structure spanning 10 levels from general laborers to Transnet executives. The application serves as a central hub for managing port operations, including vessel tracking, container management, task assignments, and third-party system integrations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development patterns
- **Build Tool**: Vite configured for fast development and optimized production builds
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent UI design
- **State Management**: TanStack React Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: Radix UI primitives with custom styling for accessibility and consistency

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for REST API endpoints
- **Language**: TypeScript throughout for type consistency between client and server
- **Database ORM**: Drizzle ORM for type-safe database operations with PostgreSQL
- **Authentication**: Replit Auth using OpenID Connect for secure user authentication
- **Session Management**: Express sessions with PostgreSQL storage for persistence
- **API Design**: RESTful endpoints with role-based access control middleware

### Database Design
- **Primary Database**: PostgreSQL with Neon serverless hosting
- **Schema Management**: Drizzle Kit for migrations and schema evolution
- **Key Tables**: Users, vessels, containers, tasks, gate transactions, berths, integrations, and sessions
- **Role System**: Hierarchical access levels (1-10) with role-based permissions stored in user records

### Authentication & Authorization
- **Authentication Provider**: Replit Auth with OpenID Connect protocol
- **Session Storage**: PostgreSQL-backed sessions with configurable TTL
- **RBAC Implementation**: Middleware-based role checking with 10-level hierarchy
- **Permission Model**: Level-based access where higher levels inherit lower-level permissions
- **Security**: HTTPS-only cookies, CSRF protection, and secure session handling

### Role Hierarchy System
The system implements a 10-level role hierarchy designed for port operations:
- Level 1: General Labour/Stevedores
- Level 2: Equipment Operators  
- Level 3: Checkers/Clerks
- Level 4-5: Supervisors/Foremen
- Level 6: Marine Pilots
- Level 7: Terminal Managers
- Level 8: Harbour Masters
- Level 9: Port Directors
- Level 10: Transnet Executives

## External Dependencies

### Third-Party Services
- **Neon Database**: Serverless PostgreSQL hosting for production data storage
- **Replit Auth**: Authentication service providing OpenID Connect integration
- **PayPal SDK**: Payment processing for premium subscription management ($100/month per employer)

### Warehouse Management Integrations
- **Emydex WMS**: Warehouse management system integration for inventory tracking
- **SCADA500**: Industrial automation system for equipment monitoring
- **Dispatch System**: Logistics coordination and vehicle tracking

### Development & Deployment
- **Replit Platform**: Development environment and deployment hosting
- **Vite Plugins**: Runtime error overlay, cartographer, and dev banner for development experience
- **ESBuild**: Production bundling for server-side code optimization

### UI & Styling Dependencies
- **Radix UI**: Comprehensive component primitives for accessibility
- **Lucide React**: Icon library for consistent iconography
- **Tailwind CSS**: Utility-first CSS framework with custom port operations theme
- **shadcn/ui**: Pre-built component library built on Radix UI primitives

### Backend Libraries
- **Drizzle ORM**: Type-safe database operations with PostgreSQL dialect
- **Express Middleware**: CORS, body parsing, session management, and static file serving
- **OpenID Client**: OAuth/OIDC implementation for Replit Auth integration
- **Connect PG Simple**: PostgreSQL session store for Express sessions