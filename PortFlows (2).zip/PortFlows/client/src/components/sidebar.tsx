import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { 
  Anchor, 
  Gauge, 
  ClipboardList, 
  Users, 
  Plug, 
  CreditCard, 
  Shield,
  LogOut
} from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const getUserInitials = (user: any) => {
    if (!user) return "U";
    const firstName = user.firstName || "";
    const lastName = user.lastName || "";
    return (firstName.charAt(0) + lastName.charAt(0)).toUpperCase() || "U";
  };

  const getUserDisplayName = (user: any) => {
    if (!user) return "User";
    return `${user.firstName || ""} ${user.lastName || ""}`.trim() || user.email || "User";
  };

  const getRoleDisplay = (user: any) => {
    if (!user) return "General Labour (Level 1)";
    const role = user.role?.replace(/_/g, " ").replace(/\b\w/g, (l: string) => l.toUpperCase()) || "General Labour";
    return `${role} (Level ${user.roleLevel || 1})`;
  };

  const navigationItems = [
    { path: "/", icon: Gauge, label: "Dashboard" },
    { path: "/tasks", icon: ClipboardList, label: "Task Management" },
    { path: "/users", icon: Users, label: "User Management" },
    { path: "/integrations", icon: Plug, label: "Integration Hub" },
    { path: "/subscriptions", icon: CreditCard, label: "Subscriptions" },
    { path: "/roles", icon: Shield, label: "Role Management" }
  ];

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-card border-r border-border shadow-lg z-30">
      <div className="p-6">
        {/* Logo */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Anchor className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-bold text-lg text-foreground">PortOps</h1>
            <p className="text-xs text-muted-foreground">Maritime Operations</p>
          </div>
        </div>
        
        {/* User profile */}
        <div className="bg-muted/50 rounded-lg p-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <span className="text-sm font-semibold text-primary-foreground">
                {getUserInitials(user)}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">
                {getUserDisplayName(user)}
              </p>
              <p className="text-xs text-muted-foreground truncate">
                {getRoleDisplay(user)}
              </p>
            </div>
          </div>
        </div>
        
        {/* Navigation menu */}
        <nav className="space-y-2">
          {navigationItems.map((item) => {
            const IconComponent = item.icon;
            const isActive = location === item.path;
            
            return (
              <Link key={item.path} href={item.path}>
                <a 
                  className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                    isActive 
                      ? "bg-primary text-primary-foreground" 
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  }`}
                  data-testid={`nav-link-${item.path.replace("/", "") || "dashboard"}`}
                >
                  <IconComponent className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </a>
              </Link>
            );
          })}
        </nav>
        
        {/* Logout button */}
        <div className="absolute bottom-6 left-6 right-6">
          <Button 
            onClick={handleLogout}
            variant="outline"
            className="w-full justify-start"
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>
    </aside>
  );
}
