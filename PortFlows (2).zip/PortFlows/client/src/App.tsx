import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import Dashboard from "@/pages/dashboard";
import TaskManagement from "@/pages/task-management";
import UserManagement from "@/pages/user-management";
import IntegrationHub from "@/pages/integration-hub";
import Subscriptions from "@/pages/subscriptions";
import RoleManagement from "@/pages/role-management";
import Sidebar from "@/components/sidebar";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mb-4 mx-auto">
            <div className="w-8 h-8 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin"></div>
          </div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      {!isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          <div className="flex min-h-screen bg-background">
            <Sidebar />
            <main className="flex-1 ml-64">
              <Switch>
                <Route path="/" component={Dashboard} />
                <Route path="/tasks" component={TaskManagement} />
                <Route path="/users" component={UserManagement} />
                <Route path="/integrations" component={IntegrationHub} />
                <Route path="/subscriptions" component={Subscriptions} />
                <Route path="/roles" component={RoleManagement} />
                <Route component={NotFound} />
              </Switch>
            </main>
          </div>
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
