import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { requireOperator, requireSupervisor, requireManager, requireAdmin, requireOwner } from "./middleware/rbac";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard API
  app.get('/api/dashboard/stats', isAuthenticated, async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // User Management API
  app.get('/api/users', requireManager, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.put('/api/users/:id/role', requireAdmin, async (req, res) => {
    try {
      const { role, roleLevel } = req.body;
      const user = await storage.updateUserRole(req.params.id, role, roleLevel);
      res.json(user);
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  // Vessels API
  app.get('/api/vessels', isAuthenticated, async (req, res) => {
    try {
      const vessels = await storage.getVessels();
      res.json(vessels);
    } catch (error) {
      console.error("Error fetching vessels:", error);
      res.status(500).json({ message: "Failed to fetch vessels" });
    }
  });

  app.get('/api/vessels/:id', isAuthenticated, async (req, res) => {
    try {
      const vessel = await storage.getVessel(req.params.id);
      if (!vessel) {
        return res.status(404).json({ message: "Vessel not found" });
      }
      res.json(vessel);
    } catch (error) {
      console.error("Error fetching vessel:", error);
      res.status(500).json({ message: "Failed to fetch vessel" });
    }
  });

  app.post('/api/vessels', requireSupervisor, async (req, res) => {
    try {
      const vessel = await storage.createVessel(req.body);
      res.status(201).json(vessel);
    } catch (error) {
      console.error("Error creating vessel:", error);
      res.status(500).json({ message: "Failed to create vessel" });
    }
  });

  app.put('/api/vessels/:id', requireSupervisor, async (req, res) => {
    try {
      const vessel = await storage.updateVessel(req.params.id, req.body);
      res.json(vessel);
    } catch (error) {
      console.error("Error updating vessel:", error);
      res.status(500).json({ message: "Failed to update vessel" });
    }
  });

  // Containers API
  app.get('/api/containers', isAuthenticated, async (req, res) => {
    try {
      const containers = await storage.getContainers();
      res.json(containers);
    } catch (error) {
      console.error("Error fetching containers:", error);
      res.status(500).json({ message: "Failed to fetch containers" });
    }
  });

  app.get('/api/containers/:id', isAuthenticated, async (req, res) => {
    try {
      const container = await storage.getContainer(req.params.id);
      if (!container) {
        return res.status(404).json({ message: "Container not found" });
      }
      res.json(container);
    } catch (error) {
      console.error("Error fetching container:", error);
      res.status(500).json({ message: "Failed to fetch container" });
    }
  });

  app.post('/api/containers', requireOperator, async (req, res) => {
    try {
      const container = await storage.createContainer(req.body);
      res.status(201).json(container);
    } catch (error) {
      console.error("Error creating container:", error);
      res.status(500).json({ message: "Failed to create container" });
    }
  });

  app.put('/api/containers/:id', requireOperator, async (req, res) => {
    try {
      const container = await storage.updateContainer(req.params.id, req.body);
      res.json(container);
    } catch (error) {
      console.error("Error updating container:", error);
      res.status(500).json({ message: "Failed to update container" });
    }
  });

  // Tasks API
  app.get('/api/tasks', isAuthenticated, async (req, res) => {
    try {
      const tasks = await storage.getTasks();
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.get('/api/tasks/my', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tasks = await storage.getTasksByUser(userId);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching user tasks:", error);
      res.status(500).json({ message: "Failed to fetch user tasks" });
    }
  });

  app.post('/api/tasks', requireSupervisor, async (req, res) => {
    try {
      const task = await storage.createTask(req.body);
      res.status(201).json(task);
    } catch (error) {
      console.error("Error creating task:", error);
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  app.put('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      // Get the task to check ownership
      const existingTask = await storage.getTask(req.params.id);
      if (!existingTask) {
        return res.status(404).json({ message: "Task not found" });
      }

      const currentUser = req.currentUser || await storage.getUser(req.user.claims.sub);
      const userLevel = currentUser?.roleLevel || 1;
      const isAssignee = existingTask.assignedTo === currentUser?.id;
      const isSupervisor = userLevel >= 4;

      // Check permissions
      if (!isAssignee && !isSupervisor) {
        return res.status(403).json({ 
          message: "Can only update tasks assigned to you or if you are a supervisor" 
        });
      }

      // Field restrictions based on role
      const allowedFields = isAssignee && !isSupervisor 
        ? ['status', 'completedAt'] // Assignees can only update status and completion
        : Object.keys(req.body); // Supervisors can update all fields

      const updateData: any = {};
      for (const field of allowedFields) {
        if (req.body[field] !== undefined) {
          updateData[field] = req.body[field];
        }
      }

      if (Object.keys(updateData).length === 0) {
        return res.status(400).json({ message: "No valid fields to update" });
      }

      const task = await storage.updateTask(req.params.id, updateData);
      res.json(task);
    } catch (error) {
      console.error("Error updating task:", error);
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  // Gate transactions API
  app.get('/api/gate-transactions', isAuthenticated, async (req, res) => {
    try {
      const transactions = await storage.getGateTransactions();
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching gate transactions:", error);
      res.status(500).json({ message: "Failed to fetch gate transactions" });
    }
  });

  app.post('/api/gate-transactions', requireOperator, async (req: any, res) => {
    try {
      const transaction = await storage.createGateTransaction({
        ...req.body,
        processedBy: req.currentUser.id,
      });
      res.status(201).json(transaction);
    } catch (error) {
      console.error("Error creating gate transaction:", error);
      res.status(500).json({ message: "Failed to create gate transaction" });
    }
  });

  // Berths API
  app.get('/api/berths', isAuthenticated, async (req, res) => {
    try {
      const berths = await storage.getBerths();
      res.json(berths);
    } catch (error) {
      console.error("Error fetching berths:", error);
      res.status(500).json({ message: "Failed to fetch berths" });
    }
  });

  app.put('/api/berths/:id', requireSupervisor, async (req, res) => {
    try {
      const berth = await storage.updateBerth(req.params.id, req.body);
      res.json(berth);
    } catch (error) {
      console.error("Error updating berth:", error);
      res.status(500).json({ message: "Failed to update berth" });
    }
  });

  // Integrations API
  app.get('/api/integrations', isAuthenticated, async (req, res) => {
    try {
      const integrations = await storage.getIntegrations();
      res.json(integrations);
    } catch (error) {
      console.error("Error fetching integrations:", error);
      res.status(500).json({ message: "Failed to fetch integrations" });
    }
  });

  app.put('/api/integrations/:id', requireAdmin, async (req, res) => {
    try {
      const integration = await storage.updateIntegration(req.params.id, req.body);
      res.json(integration);
    } catch (error) {
      console.error("Error updating integration:", error);
      res.status(500).json({ message: "Failed to update integration" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}