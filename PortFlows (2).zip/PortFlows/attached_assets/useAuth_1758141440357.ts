import { useState, useEffect } from 'react';
import { apiRequest } from '../lib/queryClient';
import type { User } from '../../../shared/schema';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const userData = await apiRequest<User>('/auth/user');
        setUser(userData);
      } catch (error) {
        console.log('User not authenticated');
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUser();
  }, []);

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
  };
}