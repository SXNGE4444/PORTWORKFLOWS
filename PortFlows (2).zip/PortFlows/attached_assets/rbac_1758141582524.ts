import type { RequestHandler } from "express";
import { storage } from "../storage";

// Role hierarchy levels (higher number = more permissions)
const ROLE_LEVELS: Record<string, number> = {
  'general_labour': 1,
  'stevedore': 1,
  'equipment_operator': 2,
  'checker': 3,
  'clerk': 3,
  'supervisor': 4,
  'foreman': 5,
  'marine_pilot': 6,
  'terminal_manager': 7,
  'harbour_master': 8,
  'port_director': 9,
  'executive': 10,
  'owner': 11,
};

export function requireRole(minimumLevel: number): RequestHandler {
  return async (req: any, res, next) => {
    try {
      if (!req.isAuthenticated() || !req.user?.claims?.sub) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }

      const userLevel = user.roleLevel || ROLE_LEVELS[user.role || 'general_labour'] || 1;
      
      if (userLevel < minimumLevel) {
        return res.status(403).json({ 
          message: "Insufficient permissions",
          required: minimumLevel,
          current: userLevel
        });
      }

      // Attach user info to request for use in handlers
      req.currentUser = user;
      next();
    } catch (error) {
      console.error("RBAC middleware error:", error);
      res.status(500).json({ message: "Authorization check failed" });
    }
  };
}

// Common role checks
export const requireOperator = requireRole(2);       // Equipment operators and above
export const requireSupervisor = requireRole(4);     // Supervisors and above  
export const requireManager = requireRole(7);        // Terminal managers and above
export const requireAdmin = requireRole(9);          // Port directors and above
export const requireOwner = requireRole(11);         // System owner only